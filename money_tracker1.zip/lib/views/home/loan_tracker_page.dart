import 'package:flutter/material.dart';

class LoanTrackerPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Loan Tracker")),
      body: Center(child: Text("Track your loans here!")),
    );
  }
}
